var bio = {
    "name": "Jonathan Puglia",
    "role": "Dad and Coffee Roaster",
    "welcomeMessage": "Welcome to the Jungle",
    "biopic": "images/bPic.png",
    "contacts": {
        "mobile": "2155202685",
        "email": "jmpuglia@gmail.com",
        "github": "jmpuglia",
        "location": "Madrid, NY"
    },
    "skills": ["Consummate Learner", "Imaginative Problem-Solver", "Team Builder", "Mission-Oriented"],
    display: function() {
        var formattedName = HTMLheaderName.replace("%data%", bio.name);
        $("#header").append(formattedName);
        var formattedPic = HTMLbioPic.replace("%data%", bio.biopic);
        var formattedWelcome = HTMLwelcomeMsg.replace("%data%", bio.welcomeMessage);
        $("#header").prepend(formattedWelcome, formattedPic);
        if (bio.skills.length > 0) {
            $("#header").append(HTMLskillsStart);
            var n = 0;
            var formattedSkill = " ";
            while (n < bio.skills.length) {
                formattedSkill = HTMLskills.replace("%data%", bio.skills[n]);
                $("#skills").append(formattedSkill);
                n = n + 1;
            }
            var formattedContactPhone = HTMLmobile.replace("%data%", bio.contacts.mobile);
            var formattedContactEmail = HTMLemail.replace("%data%", bio.contacts.email);
            var formattedContactGithub = HTMLgithub.replace("%data%", bio.contacts.github);
            var formattedContactLocation = HTMLlocation.replace("%data%", bio.contacts.location);
            $("#footerContacts, #header").append(formattedContactPhone, formattedContactEmail, formattedContactGithub, formattedContactLocation);
        }
    }
};

bio.display();

var showMore = function() {
    var formattedRole = HTMLheaderRole.replace("%data%", bio.role);
    $("h4").append(formattedRole);
};

var work = {
    "jobs": [{
            "employer": "The Puglia Homestead",
            "title": "Full Time Dad",
            "location": "Madrid, NY",
            "dates": "February 2016 - present",
            "description": "Being a full-time parent is a constant lesson in being adaptable. It's a lot of everything.<br>Also: <br>- Maintained a part-time side income in coffee roasting and consulting.<br>- Was able to make time for extended education by learning programming through Udacity."
        },

        {
            "employer": "National Coffee",
            "title": "Operations Specialist",
            "location": "Potsdam, NY",
            "dates": "May 2014 - February 2016",
            "description": "Operations Specialist is a professional Jack of All Trades. <br>Leaning on my intelligence and willingness to jump into new things, I moving around the company to fulfill various roles as needed, including: <br> - Manager for bagel restaraunt: fulfilling various leadership and executive roles. This also included all roles in the store as needed, like opener, closer, and sandwich maker, etc.<br>- Overnight Baker: Became proficient in all bakery needs, including high-volume dough making and baking, and early-morning delivery.<br>- Coffee Roaster: Learned and mastered the science of Coffee Roasting to a high level of proficiency. Also, packaging, shipping, and billing respobsibilites."
        }, {
            "employer": "Wal-Mart Potsdam",
            "title": "Backroom ZS",
            "location": "Potsdam, NY",
            "dates": "September 2010 - May 2014",
            "description": "After promotions, my final position at Wal-Mart was Backroom ZS. Responsibilities included:<br>- Improving and maintaining logistical flow of product into the store and to the customer. <br>- Leadership of a team of employees that ran 24 hours over 3 shifts.<br>- HR involvment including discipline, hiring, and firing.<br>- Substitute supervision duties into other areas of the store as needed.<br>- Fulfilling off-position duties as urgency dictated."
        }
    ],
    display: function() {
        for (var job = 0; job < work.jobs.length; job++) {
            $("#workExperience").append(HTMLworkStart);

            var formattedEmployer = HTMLworkEmployer.replace("%data%", work.jobs[job].employer);
            var formattedTitle = HTMLworkTitle.replace("%data%", work.jobs[job].title);
            var formattedEmployerTitle = formattedEmployer + formattedTitle;
            var formattedDates = HTMLworkDates.replace("%data%", work.jobs[job].dates);
            var formattedPlace = HTMLworkLocation.replace("%data%", work.jobs[job].location);
            var formattedSeeMore = HTMLworkSeeMore.replace("%data%", job);
            $(".work-entry:last").append(formattedEmployerTitle, formattedDates, formattedPlace, formattedSeeMore);
            var formattedDescription = HTMLworkDescription.replace("%data%", work.jobs[job].description);
            formattedDescription = formattedDescription.replace("%doto%", job);
            $(".seemore:last").append(formattedDescription);
        }
    }
};

var showDescription = function(input) {
    // Shows and Hides the "Read More" of each Work Experience item
    if (document.getElementById(input).style.display === 'none') {
        document.getElementById(input).style.display = 'block';
    } else {
        document.getElementById(input).style.display = 'none';
    }
};


work.display();

var projects = {
    "projects": [{
        "title": "non-existant project",
        "dates": "finished at some point",
        "description": "This is a place-holder",
        "images": ["images/ProjectPic1.jpg"]
    }, {
        "title": "another project!",
        "dates": "the end of time",
        "description": "This is a place-holder",
        "images": ["images/ProjectPic2.jpg"]
    }],
    display: function() {
        for (var project = 0; project < projects.projects.length; project++) {
            $("#projects").append(HTMLprojectStart);
            var formattedProjectTitle = HTMLprojectTitle.replace("%data%", projects.projects[project].title);
            var formattedDates = HTMLprojectDates.replace("%data%", projects.projects[project].dates);
            var formattedProjectDescription = HTMLprojectDescription.replace("%data%", projects.projects[project].description);
            $(".project-entry:last").append(formattedProjectTitle, formattedDates, formattedProjectDescription);
            for (var image = 0; image < projects.projects[project].images.length; image++) {
                var formattedImage = HTMLprojectImage.replace("%data%", projects.projects[project].images[image]);
                $(".project-entry:last").append(formattedImage);
            }
        }
    }
};

projects.display();


var education = {
    "schools": [{
        "name": "Shippensburg University of PA",
        "location": "Shippensburg, PA",
        "majors": ["Psychology (Neuroscience)"],
        "degree": "Bachelor of Science",
        "minors": [],
        "url": "www.ship.edu",
        "dates": "2003 - 2007"
    }, ],
    "onlineCourses": [{
        "school": "Udacity",
        "title": "Intro to Programming",
        "dates": "March 2016 - December 2016",
        "url": "www.udacity.com"
    }],
    display: function() {
        $("#education").append(HTMLschoolStartHeader);

        for (var school = 0; school < education.schools.length; school++) {
            $("#education").append(HTMLschoolStartDiv);
            var formattedSchoolName = HTMLschoolName.replace("%data%", education.schools[school].name);
            var formattedSchoolDegree = HTMLschoolDegree.replace("%data%", education.schools[school].degree);
            var formattedSchoolLocation = HTMLschoolLocation.replace("%data%", education.schools[school].location);
            var formattedschoolDates = HTMLschoolDates.replace("%data%", education.schools[school].dates);
            $(".education-entry:first").append(formattedSchoolName, formattedSchoolDegree, formattedSchoolLocation, formattedschoolDates);
            for (var major = 0; major < education.schools[school].majors.length; major++) {
                var formattedSchoolMajor = HTMLschoolMajor.replace("%data%", education.schools[school].majors[major]);
                $(".education-entry:first").append(formattedSchoolMajor);
            }
            for (var minor = 0; minor < education.schools[school].minors.length; minor++) {
                var formattedSchoolMinor = HTMLschoolMinor.replace("%data%", education.schools[school].minors[minor]);
                $(".education-entry:first").append(formattedSchoolMinor);
            }
            var formattedSchoolURL = HTMLonlineURL.replace("%data%", education.schools[school].url);
            $(".education-entry:first").append(formattedSchoolURL);

        }
        if (education.onlineCourses.length > 0) {
            $("#education").append(HTMLonlineClassesHeader);
            for (var course = 0; course < education.onlineCourses.length; course++) {
                $("#education").append(HTMLonlineClassesDiv);
                var formattedCourseName = HTMLonlineTitle.replace("%data%", education.onlineCourses[course].school);
                var formattedOnlineSchool = HTMLonlineSchool.replace("%data%", education.onlineCourses[course].title);
                var formattedOnlineDates = HTMLonlineDates.replace("%data%", education.onlineCourses[course].dates);
                var formattedOnlineLink = HTMLonlineURL.replace("%data%", education.onlineCourses[course].url);
                $(".education-entry:last").append(formattedCourseName, formattedOnlineSchool, formattedOnlineDates, formattedOnlineLink);
            }
        }
    }
};

education.display();




// function inName(nameObj) {
// 	var nameArray = [];
// 	nameArray = nameObj.split(" ");
// 	var firstName = nameArray[0].charAt(0).toUpperCase() + nameArray[0].slice(1).toLowerCase();
// 	var nameTranslate = firstName + " " + nameArray[1].toUpperCase();
// 	console.log(nameTranslate);
// 	return nameTranslate;

// };


// $("#main").append(internationalizeButton);

$("#mapDiv").append(googleMap);